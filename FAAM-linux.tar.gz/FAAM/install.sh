#!/usr/bin/env bash
# Optional: add FAAM to your applications menu and a 'faam' command.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/.local/share/faam"
mkdir -p "$APP" "$HOME/.local/share/applications" "$HOME/.local/bin"
cp -R "$SRC/." "$APP/"
chmod +x "$APP/run-faam.sh"
sed "s#@APP@#$APP#g" "$SRC/FAAM.desktop" > "$HOME/.local/share/applications/faam.desktop"
ln -sf "$APP/run-faam.sh" "$HOME/.local/bin/faam"
command -v update-desktop-database >/dev/null 2>&1 && \
  update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
echo "FAAM installed."
echo "  • Launch it from your apps menu (search 'FAAM'), or"
echo "  • run:  faam"
echo "If 'faam' isn't found, add this to your shell profile:"
echo '  export PATH="$HOME/.local/bin:$PATH"'
