FAAM for Windows
================

QUICK START
1) Install Python 3.9+ from https://www.python.org/downloads/
   IMPORTANT: tick "Add Python to PATH" during setup.
2) Double-click  Start FAAM.bat
3) Your browser opens to FAAM automatically once it's ready.
   Create an account or sign in, and you're in.

That's it - FAAM runs locally on your PC and you use it in your browser.
You do NOT need an OpenAI key; add one only if you want the AI assistant
(you can paste it when the launcher asks, or just press Enter to skip).

TROUBLESHOOTING
- "Nothing happens / it opens the Microsoft Store": Windows shipped a fake
  "python" shortcut. Install Python from the link above (Add to PATH), or turn
  off the alias in  Settings > Apps > Advanced app settings >
  App execution aliases  (toggle off python.exe / python3.exe).
- "The page won't load at first": give it a few seconds - the launcher waits
  for the server and opens your browser when it's ready.
- To stop FAAM: close the black launcher window.

LINUX: grab the Linux package at /download/linux (or just run python3 app.py).

NOT FINANCIAL ADVICE. FAAM never places trades - it prepares orders for you to review.
